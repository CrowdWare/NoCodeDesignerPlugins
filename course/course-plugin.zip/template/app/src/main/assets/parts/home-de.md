# Willkommen beim Kurs für den Kurs-Builder
Bitte öffne nun das Menu mit einem Tab auf das ☰ Hamburger Symbol oben links und wähle eine Lektion aus der Liste aus.

Du kannst das Menu wieder schliessen, um mehr Platz für die eigentliche Lektion zu haben.