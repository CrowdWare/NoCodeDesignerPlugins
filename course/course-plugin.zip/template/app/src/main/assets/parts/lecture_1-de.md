# Lecture 1
Ipsum lorem sehr lange Zeile mit viel Inhalt, um zu zeigen, das das Animieren auch wirklich gut funktioniert.